document.getElementById('search-train').addEventListener('click', () => {
    let inputValue = document.getElementById('depart-from').value;
});
// add search functionality