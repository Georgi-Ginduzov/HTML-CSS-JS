let form = document.querySelector(`#train-submission-form`);

form.addEventListener('submit', function(event) {
    event.preventDefault();
    let city = document.querySelector(`#depart-from-city`).value;
    window.location.href = `http://127.0.0.1:5501/plan-jorney.html?city=${city}`;

    //
    const displayData =(weather)=>{
        let celsius = weather.main.temp - 273.15; // convert Kelvin to Celsius
        temp.innerText = `${celsius.toFixed(2)}°C`; // display temperature in Celsius
    }
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid={727082d3fd0bf61dfdddeef1bfd1398a}`)
    .then(response => response.json())
    .then(displayData)
    .catch(err => alert("Wrong city name!"));
});